# Bootstrap 3 Offline Docs

*Up to date with v3.3.5*

## Usage

1. Download the [files](https://github.com/AAlakkad/Bootstrap-3-Offline-Docs/archive/master.zip).
2. Extract zip file.
3. Open `index.html` in a browser.


## Note
You can compile the official docs yourself with Jekyll.
